import urllib.parse
import requests

with open("hostnames.txt", "r") as f:
    urls = f.read().splitlines()

# XSS Payload
payload = urllib.parse.quote("'><script>alert(1)</script>")

for url in urls:
    try:
        full_url = f"{url}/?{payload}"
        response = requests.get(full_url, timeout=5)
        if "Request Rejected" in response.text or response.status_code == 403:
            print(url)
    except requests.RequestException:
        continue
